 
            API Functional Details 
            queryNumber : Checks the plate number of the car for duplicate entry
            queryAvailableSpace : Car Model id AND plate Number to query and Get Response 
            getCarBlock : get the location of the block where the car is parked
            freeCarBlock : remove the entry and mark block free again
            queryHashMap : every block will have a max capacity (max Items ) Current Value is set to 2 


Program uses HashMap for Insert and Update
Logging Input / output events to a logfile 






 


